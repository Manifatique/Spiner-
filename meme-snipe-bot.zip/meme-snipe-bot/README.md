# Meme Snipe Telegram Bot — mode papier sécurisé

Bot Telegram Python pour surveiller des paires DEX, filtrer des opportunités à haut risque, notifier dans Telegram, simuler des entrées/sorties et reproduire des signaux de copy-trading en portefeuille papier.

## Ce que le projet fait

- Interroge périodiquement l'API publique Dexscreener.
- Applique des filtres de liquidité, volume, âge, variation de prix et présence d'adresse.
- Envoie des alertes Telegram avec score de risque et raisons du rejet.
- Maintient un portefeuille papier SQLite, PnL réalisé/non réalisé et historique.
- Accepte des signaux de copie manuels via Telegram : `/copy SYMBOL BUY ENTRY STOP TP SIZE`.
- Simule les prises de profit et stops sur les prix observés.
- Limite les utilisateurs aux `ALLOWED_CHAT_IDS`.
- Ne demande ni ne stocke de seed phrase, clé privée ou secret de wallet.

## Limite importante

Le bot est **paper-trading uniquement**. Il ne signe, ne diffuse et ne soumet aucune transaction. Le “sniping” crypto et le copy trading de meme coins peuvent entraîner une perte totale, des honeypots, des taxes cachées, du MEV et des manipulations. Les scores sont des filtres heuristiques, pas des garanties.

## Installation

```bash
cp .env.example .env
# renseigner TELEGRAM_BOT_TOKEN et ALLOWED_CHAT_IDS
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
python -m app.main
```

## Docker

```bash
cp .env.example .env
docker compose up --build
```

## Commandes Telegram

- `/start` — aide et état.
- `/status` — solde papier et paramètres.
- `/scan` — lancer un scan immédiat.
- `/watch QUERY` — modifier la recherche de paires, ex. `/watch SOL`.
- `/copy SYMBOL BUY ENTRY STOP TP SIZE` — créer un trade papier, ex. `/copy BONK BUY 0.00002 0.000018 0.000024 25`.
- `/positions` — positions ouvertes.
- `/close SYMBOL` — clôturer une position au dernier prix connu.
- `/pause` / `/resume` — arrêter/reprendre les entrées papier.

## Déploiement

Pour un fonctionnement 24/7, utiliser un hébergement persistant avec sauvegarde de `data/bot.sqlite3`, variables d'environnement chiffrées et supervision. Ne jamais mettre `.env` dans Git.

## Tests

```bash
pytest -q
```
