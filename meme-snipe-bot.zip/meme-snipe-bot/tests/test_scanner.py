from app.models import Pair
from app.scanner import DexScanner
class S: min_liquidity_usd=25000; min_volume_5m_usd=5000; max_token_age_minutes=30; max_price_impact_pct=3; chain_id='solana'
def test_score_good_pair():
    p=Pair('solana','a','TEST','Test',1,30000,6000,2,10,'url'); assert DexScanner(S()).evaluate(p).score==100
def test_score_bad_pair():
    p=Pair('solana','a','TEST','Test',1,1,1,20,100,'url'); assert DexScanner(S()).evaluate(p).score==15
