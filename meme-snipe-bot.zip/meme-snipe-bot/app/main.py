import asyncio, logging, os
from aiogram import Bot, Dispatcher, Router
from aiogram.filters import Command
from aiogram.types import Message
from .config import Settings
from .paper import PaperBroker
from .scanner import DexScanner

s=Settings(); logging.basicConfig(level=getattr(logging,s.log_level.upper(),logging.INFO)); bot=Bot(s.telegram_bot_token); dp=Dispatcher(); r=Router(); dp.include_router(r)
broker=PaperBroker(s.database_path,s.paper_starting_balance_usd); scanner=DexScanner(s); paused=False; alerted=set()

def allowed(m): return m.chat.id in s.allowed_ids
async def reply(m,t):
    if allowed(m): await m.answer(t)

@r.message(Command('start'))
async def start(m:Message): await reply(m, 'Bot actif en MODE PAPIER.\n/scan /status /positions\n/copy SYMBOL BUY ENTRY STOP TP SIZE\n/close SYMBOL\n/pause /resume /watch QUERY')
@r.message(Command('status'))
async def status(m:Message):
    if not allowed(m): return
    cash, ps=await broker.summary(); await m.answer(f'Mode: PAPER\nSolde disponible: ${cash:.2f}\nPositions: {len(ps)}\nRecherche: {s.watchlist_query}\nRéseau: {s.chain_id}')
@r.message(Command('positions'))
async def positions(m:Message):
    if not allowed(m): return
    _, ps=await broker.summary(); await m.answer('Aucune position.' if not ps else '\n'.join(f'{p[0]} qty={p[1]:.4g} entry=${p[2]:.8g} stop=${p[3]:.8g} tp=${p[4]:.8g}' for p in ps))
@r.message(Command('scan'))
async def scan(m:Message):
    if not allowed(m): return
    try: rows=await scanner.fetch(); good=[scanner.evaluate(x) for x in rows]
    except Exception as e: await m.answer(f'Scan indisponible: {e}'); return
    good=sorted(good,key=lambda x:x.score,reverse=True)[:8]
    if not good: await m.answer('Aucune paire trouvée.'); return
    await m.answer('\n\n'.join(f'{x.pair.symbol} score {x.score}/100 | liq ${x.pair.liquidity_usd:,.0f} | vol5m ${x.pair.volume_5m_usd:,.0f} | Δ5m {x.pair.price_change_5m_pct:.2f}%\n{x.pair.url}\n' + ('OK' if not x.reasons else 'Filtres: '+', '.join(x.reasons)) for x in good))
@r.message(Command('copy'))
async def copy(m:Message):
    if not allowed(m): return
    global paused
    if paused: await m.answer('Entrées en pause.'); return
    a=m.text.split()
    if len(a)!=7 or a[2].upper()!='BUY': await m.answer('Usage: /copy SYMBOL BUY ENTRY STOP TP SIZE'); return
    try: symbol,_,entry,stop,tp,size=a[1],a[2],*map(float,a[3:])
    except ValueError: await m.answer('Valeurs numériques invalides.'); return
    if size>s.max_position_usd: await m.answer(f'Taille limitée à ${s.max_position_usd:.2f}.'); return
    ok,msg=await broker.open(symbol.upper(),entry,stop,tp,size); await m.answer(msg)
@r.message(Command('close'))
async def close(m:Message):
    if not allowed(m): return
    a=m.text.split();
    if len(a)!=2: await m.answer('Usage: /close SYMBOL'); return
    rows=await scanner.fetch(); price=next((x.price_usd for x in rows if x.symbol.upper()==a[1].upper()),0)
    if not price: await m.answer('Prix introuvable, clôture non effectuée.'); return
    _,msg=await broker.close(a[1].upper(),price); await m.answer(msg)
@r.message(Command('pause'))
async def pause(m:Message):
    global paused
    if allowed(m): paused=True; await m.answer('Entrées papier en pause.')
@r.message(Command('resume'))
async def resume(m:Message):
    global paused
    if allowed(m): paused=False; await m.answer('Entrées papier reprises.')
@r.message(Command('watch'))
async def watch(m:Message):
    if allowed(m) and len(m.text.split())==2: s.watchlist_query=m.text.split()[1]; await m.answer(f'Recherche définie sur {s.watchlist_query}')

async def loop():
    while True:
        try:
            rows=await scanner.fetch()
            for pair in rows:
                signal=scanner.evaluate(pair)
                key=f'{pair.chain}:{pair.address}'
                if signal.score >= 65 and key not in alerted:
                    alerted.add(key)
                    text=(f'ALERTE PAPER — {pair.symbol} score {signal.score}/100\n'
                          f'Prix ${pair.price_usd:.8g} | liquidité ${pair.liquidity_usd:,.0f} | volume 5m ${pair.volume_5m_usd:,.0f}\n'
                          f'{pair.url}\nAucune transaction réelle n’est exécutée.')
                    for chat_id in s.allowed_ids:
                        await bot.send_message(chat_id,text)
            if len(alerted)>5000: alerted.clear()
        except Exception as exc:
            logging.warning('scan automatique échoué: %s', exc)
        await asyncio.sleep(s.scan_interval_seconds)
async def main():
    os.makedirs(os.path.dirname(s.database_path) or '.',exist_ok=True); await broker.init(); await asyncio.gather(dp.start_polling(bot),loop())
if __name__=='__main__': asyncio.run(main())
