from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    telegram_bot_token: str
    allowed_chat_ids: str
    scan_interval_seconds: int = 30
    chain_id: str = "solana"
    watchlist_query: str = "SOL"
    min_liquidity_usd: float = 25_000
    min_volume_5m_usd: float = 5_000
    max_token_age_minutes: int = 30
    max_price_impact_pct: float = 3
    max_position_usd: float = 50
    max_daily_loss_usd: float = 25
    paper_starting_balance_usd: float = 1_000
    database_path: str = "data/bot.sqlite3"
    log_level: str = "INFO"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def allowed_ids(self) -> set[int]:
        return {int(x.strip()) for x in self.allowed_chat_ids.split(",") if x.strip()}
