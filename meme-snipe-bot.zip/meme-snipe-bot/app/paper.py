import aiosqlite
from datetime import datetime, timezone

class PaperBroker:
    def __init__(self, path, starting): self.path, self.starting = path, starting
    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.execute('CREATE TABLE IF NOT EXISTS account (id INTEGER PRIMARY KEY, cash REAL NOT NULL)')
            await db.execute('CREATE TABLE IF NOT EXISTS positions (symbol TEXT PRIMARY KEY, qty REAL, entry REAL, stop REAL, take REAL, invested REAL)')
            await db.execute('CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, side TEXT, price REAL, qty REAL, pnl REAL, ts TEXT)')
            cur = await db.execute('SELECT COUNT(*) FROM account'); n = (await cur.fetchone())[0]
            if not n: await db.execute('INSERT INTO account(id,cash) VALUES(1,?)', (self.starting,))
            await db.commit()
    async def open(self, symbol, price, stop, take, usd):
        if usd <= 0 or price <= 0: return False, 'montant ou prix invalide'
        async with aiosqlite.connect(self.path) as db:
            if (await (await db.execute('SELECT 1 FROM positions WHERE symbol=?',(symbol,))).fetchone()): return False, 'position déjà ouverte'
            cash = (await (await db.execute('SELECT cash FROM account WHERE id=1')).fetchone())[0]
            if usd > cash: return False, 'solde papier insuffisant'
            await db.execute('UPDATE account SET cash=cash-? WHERE id=1',(usd,))
            await db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?)',(symbol,usd/price,price,stop,take,usd))
            await db.execute('INSERT INTO trades(symbol,side,price,qty,pnl,ts) VALUES(?,?,?,?,?,?)',(symbol,'BUY',price,usd/price,0,datetime.now(timezone.utc).isoformat()))
            await db.commit(); return True, f'position papier ouverte: ${usd:.2f}'
    async def close(self, symbol, price):
        async with aiosqlite.connect(self.path) as db:
            p = await (await db.execute('SELECT qty,entry,invested FROM positions WHERE symbol=?',(symbol,))).fetchone()
            if not p: return False, 'position inconnue'
            qty, entry, invested = p; value=qty*price; pnl=value-invested
            await db.execute('UPDATE account SET cash=cash+? WHERE id=1',(value,)); await db.execute('DELETE FROM positions WHERE symbol=?',(symbol,))
            await db.execute('INSERT INTO trades(symbol,side,price,qty,pnl,ts) VALUES(?,?,?,?,?,?)',(symbol,'SELL',price,qty,pnl,datetime.now(timezone.utc).isoformat())); await db.commit()
            return True, f'position clôturée, PnL ${pnl:.2f}'
    async def summary(self):
        async with aiosqlite.connect(self.path) as db:
            cash=(await (await db.execute('SELECT cash FROM account WHERE id=1')).fetchone())[0]; ps=await (await db.execute('SELECT symbol,qty,entry,stop,take,invested FROM positions')).fetchall()
        return cash, ps
