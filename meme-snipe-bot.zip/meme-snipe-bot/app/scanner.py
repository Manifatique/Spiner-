from datetime import datetime, timezone
import httpx
from .models import Pair, Signal

class DexScanner:
    BASE = "https://api.dexscreener.com/latest/dex/search"
    def __init__(self, settings): self.s = settings
    async def fetch(self) -> list[Pair]:
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.get(self.BASE, params={"q": self.s.watchlist_query})
            r.raise_for_status()
            rows = r.json().get("pairs", [])
        out = []
        for x in rows:
            if x.get("chainId") != self.s.chain_id: continue
            liq = float((x.get("liquidity") or {}).get("usd") or 0)
            vol = float((x.get("volume") or {}).get("m5") or 0)
            chg = float((x.get("priceChange") or {}).get("m5") or 0)
            created = x.get("pairCreatedAt")
            age = (datetime.now(timezone.utc).timestamp()*1000 - created)/60000 if created else 999999
            try: price = float(x.get("priceUsd") or 0)
            except (TypeError, ValueError): price = 0
            out.append(Pair(self.s.chain_id, x.get("pairAddress", ""), (x.get("baseToken") or {}).get("symbol", "?"), (x.get("baseToken") or {}).get("name", "?"), price, liq, vol, chg, age, x.get("url", "")))
        return out
    def evaluate(self, pair: Pair) -> Signal:
        reasons=[]; score=0
        if pair.liquidity_usd >= self.s.min_liquidity_usd: score += 25
        else: reasons.append(f"liquidité faible: ${pair.liquidity_usd:,.0f}")
        if pair.volume_5m_usd >= self.s.min_volume_5m_usd: score += 20
        else: reasons.append(f"volume 5m faible: ${pair.volume_5m_usd:,.0f}")
        if pair.age_minutes <= self.s.max_token_age_minutes: score += 20
        else: reasons.append(f"paire âgée de {pair.age_minutes:.0f} min")
        if 0 < pair.price_change_5m_pct <= self.s.max_price_impact_pct: score += 20
        elif pair.price_change_5m_pct > self.s.max_price_impact_pct: reasons.append("hausse 5m excessive / risque de chase")
        else: reasons.append("variation 5m non confirmée")
        if pair.address: score += 15
        else: reasons.append("adresse absente")
        return Signal(pair, score, reasons, datetime.now(timezone.utc))
