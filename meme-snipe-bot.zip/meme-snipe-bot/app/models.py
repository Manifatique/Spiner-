from dataclasses import dataclass
from datetime import datetime

@dataclass
class Pair:
    chain: str
    address: str
    symbol: str
    name: str
    price_usd: float
    liquidity_usd: float
    volume_5m_usd: float
    price_change_5m_pct: float
    age_minutes: float
    url: str

@dataclass
class Signal:
    pair: Pair
    score: int
    reasons: list[str]
    created_at: datetime
